console.log('Async Await JS File included');

let result1 = document.getElementById('result1');
let result2 = document.getElementById('result2');
let result3 = document.getElementById('result3');

let dell = {
    brand: 'Dell',
    hardDisk: '2 TB',
    color: 'Black'
}

let hp = {
    brand: 'HP',
    hardDisk: '2 TB',
    color: 'Silver'
}

let noLaptop = {
    brand: 'NA',
    status: 'error'
}

let buyLaptop = new Promise((resolve, reject) => {
    setTimeout(()=> {
        resolve(dell);
    },4000);
});

let buyLaptop2 = fetch('https://jsonplaceholder.typicode.com/posts')
.then(response => response.json());

function clearData() {
    result1.innerText = "";
}

function clearData2() {
    result2.innerText = "";
}

function clearData3() {
    result3.innerText = "";
}

// with promise
function getData() {
    result1.innerText = 'Fetching Data .......';
    buyLaptop.then((res)=>{
        result1.innerText = JSON.stringify(res);
    })
}


// with async/await
async function getData2() {
    result2.innerText = 'Fetching Data .......';
    let res = await buyLaptop;
    result2.innerText = JSON.stringify(res);
}

// with fetch api
  // --- with promise
//   function getData3() {
//     result3.innerText = "Fetching Data .......";
//     buyLaptop2.then((res)=>{
//         result3.innerText = JSON.stringify(res);
//     })
//   }

  // --- with async/await
  async function getData3() {
    result3.innerText = 'Fetching Data .......';
    let res = await buyLaptop2;
    result3.innerText = JSON.stringify(res); 
  }

